from odoo import models, fields, api

class ServiceRequest(models.Model):
    _name = 'service.request'
    _description = 'Service Request'

    name = fields.Char(string='Request ID', required=True, copy=False, readonly=True, default='New')
    title = fields.Char(string='Title', required=True)
    description = fields.Text(string='Description')
    request_date = fields.Date(string='Request Date', default=fields.Date.today)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('in_progress', 'In Progress'),
        ('done', 'Done'),
        ('cancelled', 'Cancelled'),
    ], string='Status', default='draft')

    @api.model
    def create(self, vals):
        if vals.get('name', 'New') == 'New':
            vals['name'] = self.env['ir.sequence'].next_by_code('service.request') or 'New'
        return super(ServiceRequest, self).create(vals)
