{
    'name': 'Service Request',
    'version': '1.0',
    'summary': 'Manage service requests',
    'category': 'Custom',
    'author': 'Your Name',
    'depends': ['base'],
    'data': [
        'security/service_request_security.xml',
        'security/ir.model.access.csv',
        'data/service_request_sequence.xml',
        'views/service_request_views.xml',
    ],
    'installable': True,
    'application': True,
}